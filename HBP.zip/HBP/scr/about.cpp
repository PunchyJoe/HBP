//about

#include "hbpheader.h"

void about(void)
{
   cout << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl;
   cout << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl;
   cout << "                         Joe Considine's" << endl;
   cout << "                         HEAVYWEIGHT BOXING PROMOTER  " << endl;
   cout << "                         VERSION: " << __DATE__ << " " << __TIME__ << endl;
   cout << "                         joecolorado@gmx.co.uk" << endl;
   cout << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl;

   cin.sync();
   _getch();
   system("cls");

   return;
}
