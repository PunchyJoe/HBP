//help pages

#include "hbpheader.h"

void help(void)
{
   cout << "WORK IT OUT YOURSELF!!! THAT'S THE FUN OF IT!!!" << endl;

   cin.sync();
   _getch();
   system("cls");

   return;
}
